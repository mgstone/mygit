    package com.example.convertbitmap;  
    import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import android.app.Activity;  
import android.graphics.Bitmap;  
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Bitmap.Config;  
import android.graphics.drawable.BitmapDrawable;  
import android.os.Bundle;  
import android.view.Gravity;
import android.view.View;  
import android.widget.Button;  
import android.widget.ImageView;  
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
    public class MainActivity extends Activity {  
        /** Called when the activity is first created. */  
        Button  btnC,btnNeon;  
        TextView Mytext;
        TextView Mytext0;
        @Override  
        public void onCreate(Bundle savedInstanceState) {  
            super.onCreate(savedInstanceState);  
            setContentView(R.layout.activity_main);  
            
            btnC=(Button)this.findViewById(R.id.btnC);  
            btnC.setOnClickListener(new ClickEvent());  
              
            btnNeon=(Button)this.findViewById(R.id.btnNeon);  
            btnNeon.setOnClickListener(new ClickEvent());  
            Mytext=(TextView)this.findViewById(R.id.MyText);  
            Mytext0=(TextView)this.findViewById(R.id.MyText0);  
            
            Toast toast=Toast.makeText(getApplicationContext(), "Welcome to my world!", Toast.LENGTH_LONG); 
            toast.show();
        }
        class ClickEvent implements View.OnClickListener{  
            @Override  
            public void onClick(View v) {  
            	float[] array=new float[1000];
                for(int i=0;i<1000;i++){
                	array[i]=i;
                }
                if(v==btnC)  
                {  
                	float ResultOne=Convert.ConvertOne(array);
                	String finialOne=Float.toString(ResultOne);
                	Mytext.setText("C计算显示结果:"+finialOne);
                	Mytext.setTextSize(20);
                	Mytext.setTextColor(0xffff00ff);
                }  
                else if(v==btnNeon)
                {  
                	float ResultTwo=Convert.ConvertTwo(array);
                	String finialTwo=Float.toString(ResultTwo);
                	Mytext0.setText("neon计算显示结果:"+finialTwo);
                	Mytext0.setTextSize(20);
                	Mytext0.setTextColor(0xffff00ff);
                }  
            }  
        }  
    }  
