    #include <jni.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <arm_neon.h>
    extern "C" {
    JNIEXPORT jfloat JNICALL Java_com_example_convertbitmap_Convert_ConvertOne(
            JNIEnv* env, jobject obj, jfloatArray buf);
    JNIEXPORT jfloat JNICALL Java_com_example_convertbitmap_Convert_ConvertTwo(
            JNIEnv* env, jobject obj, jfloatArray buf);
    }
    ;
    JNIEXPORT jfloat JNICALL Java_com_example_convertbitmap_Convert_ConvertOne(
            JNIEnv* env, jobject obj, jfloatArray buf) {
        jfloat *cbuf;
        cbuf = env->GetFloatArrayElements(buf, false);
        if (cbuf == NULL) {
            return 0; /* exception occurred */
        }
        float sum = 0;
        for (int i = 0; i < 1000; ++i) {
             sum += cbuf[i];
        }
       return sum;
    }

    JNIEXPORT jfloat JNICALL Java_com_example_convertbitmap_Convert_ConvertTwo(
            JNIEnv* env, jobject obj, jfloatArray buf) {
    	jfloat *data;
    	int size=1000;
    	data = env->GetFloatArrayElements(buf, false);
        if (data == NULL) {
            return 0; /* exception occurred */
        }
        float sum = 0.f;
        float32x4_t sum_vec = vdupq_n_f32(0);

        for (int i = 0; i < size / 4; ++i) {
            float32x4_t tmp_vec = vld1q_f32 (data + 4*i);
            sum_vec = vaddq_f32(sum_vec, tmp_vec);
        }
        sum += vgetq_lane_f32(sum_vec, 0);
        sum += vgetq_lane_f32(sum_vec, 1);
        sum += vgetq_lane_f32(sum_vec, 2);
        sum += vgetq_lane_f32(sum_vec, 3);
        int odd = size & 3;
        if(odd) {
            for(int i = size - odd; i < size; ++i) {
                sum += data[i];
            }
        }
        return sum;
    }
