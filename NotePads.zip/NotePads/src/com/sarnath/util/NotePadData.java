package com.sarnath.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NotePadData extends SQLiteOpenHelper {
	
	 public static final String TABLE_NAME = "notepad";
	 public static final String TIME="date";
	 public static final String TITLE = "title";
	 public static final String ID="id";
	 public static final String MAIN="contentDetail";
     private static final String DATABASE_NAME="notepad.db";
     private static final int DATABASE_VERSION=1;


	public NotePadData(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String detailQql="create table notepad(id  INTEGER primary key autoincrement,date text not null, title text not null,contentDetail text not null)";
		db.execSQL(detailQql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
	}

}
