package com.sarnath.jpush;



import java.text.SimpleDateFormat;
import java.util.Date;

import com.sarnath.jpush.R;
import com.sarnath.util.ExitManager;
import com.sarnath.util.NotePadData;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WriteActivity  extends Activity{
	
	/**保存按钮初始化*/
	private Button submit;
	
	/**标题文本框初始化*/
	private EditText title;
	
	/**内容文本框初始化*/
	private EditText main;
	
	/**判断状态*/
	private  String  update_tag="0";
	

@Override
protected void onCreate(Bundle savedInstanceState) {
	
	
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.write);
	
	title = (EditText) this.findViewById(R.id.title);
	main = (EditText) this.findViewById(R.id.main);
	submit = (Button) this.findViewById(R.id.submit);
	
	// 将Activity加入到Activity容器中
	ExitManager.getInstance().addActivity(this);
	
	Bundle extras=getIntent().getExtras();
	
	//如果extras不等于空根据传递的值给标题和内容赋值
	if(extras!=null){
		
		update_tag=extras.getString("update_tag");		
		
		//判断是否是修改状态
		 if(update_tag.equals("1")){
			 
			 title.setText(extras.getString("title"));
			 main.setText(extras.getString("contentDetail"));
			
			}
		 else{
			 
			 title.setText("");
			 main.setText("");

		 }
		 
	}

			 
		
	//添加保存按钮点击事件
	submit.setOnClickListener(new OnClickListener() {
		
		/**
		 * 保存按钮响应事件
		 */
		
		public void onClick(View v) {
           
			//标题
			String titleText = title.getText().toString().trim();
			//主题
			String mainText = main.getText().toString().trim();
			
			Bundle extras=getIntent().getExtras();
			
			if(extras != null){			
				//获取update
				 update_tag= extras.getString("update_tag");
				 
				 //判断是否为修改
				 if(update_tag.equals("1")){
					 
			      String  id = extras.getString("id");
					
			      //判断标题是否为空
				if(titleText.equals("") || null==titleText) {
					Toast.makeText(getApplicationContext(),
							R.string.title_null, Toast.LENGTH_SHORT)
							.show();//提示不可为空
					
					//判断主题是否为空
				}else if(mainText.equals("") || null==mainText){
					Toast.makeText(getApplicationContext(),
							R.string.main_null, Toast.LENGTH_SHORT)
							.show();//提示不可为空
				}else{
					
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

					NotePadData dbHelper=new NotePadData(WriteActivity.this);
					SQLiteDatabase db=dbHelper.getWritableDatabase();
                   //修改
					db.execSQL("update notepad set title=?,contentDetail=?,date=? where id=?", new Object[]{titleText,mainText, df.format(new Date()),id});
					db.close();
					
					Toast.makeText(getApplicationContext(),
							R.string.update_win, Toast.LENGTH_SHORT)
							.show();
					Intent intent= new Intent(WriteActivity.this,
							NotpadActivity.class);
					startActivity(intent);// 跳转
				}
				
				 }	
				 }else{
					 //判断标题是否为空
					 if(titleText.equals("") || null==titleText) {
							Toast.makeText(getApplicationContext(),
									R.string.title_null, Toast.LENGTH_SHORT)
									.show();
							//判断内容是否为空
						}else if(mainText.equals("") || null==mainText){
							Toast.makeText(getApplicationContext(),
									R.string.main_null, Toast.LENGTH_SHORT)
									.show();
						}else{
							SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

					NotePadData dbHelper=new NotePadData(WriteActivity.this);
					SQLiteDatabase db=dbHelper.getWritableDatabase();
                    //插入
					db.execSQL("insert into notepad(title,contentDetail,date) values(?,?,?)", new Object[]{titleText,mainText, df.format(new Date())});
					db.close();
					
					Toast.makeText(getApplicationContext(),
							R.string.commit_win, Toast.LENGTH_SHORT)
							.show();
					//提示成功
					Intent intent= new Intent(WriteActivity.this,
							NotpadActivity.class);
					startActivity(intent);// 跳转
						
					
				}
		}
			}
	});
	
}
public boolean onKeyDown(int keyCode, KeyEvent event) {

	if (keyCode == KeyEvent.KEYCODE_BACK) {
		Intent intent= new Intent(WriteActivity.this,
				NotpadActivity.class);
		startActivity(intent);// 跳转
	}
	return false;
}
}
