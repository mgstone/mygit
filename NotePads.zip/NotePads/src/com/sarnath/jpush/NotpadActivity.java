package com.sarnath.jpush;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import cn.jpush.android.api.JPushInterface;

import com.sarnath.jpush.R;
import com.sarnath.util.ExitManager;
import com.sarnath.util.NotePadData;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

/**
 * @date 2014-11-27
 * @author SARNATH
 * @class description 主界面
 */
public class NotpadActivity extends Activity {
	/**新建按钮*/
	private Button  startBtn;
	
	/**列表初始化*/
	private ListView noteList;
	

	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
       setContentView(R.layout.main);
       
       JPushInterface.setDebugMode(true);
       JPushInterface.init(this);
		ExitManager.getInstance().addActivity(this);// 将MainActivity加入到Activity容器中
     
       startBtn = (Button) this.findViewById(R.id.start);
             
		ArrayList<Map<String,Object>> data=new ArrayList<Map<String,Object>>();
		Map<String,Object> item;
		
		NotePadData dbHelper=new NotePadData(NotpadActivity.this);
	    final SQLiteDatabase db=dbHelper.getReadableDatabase();
	    //查询
	    final Cursor cursor = db.rawQuery("select * from notepad", null);
	    cursor.moveToFirst();
	    
	    for(int i=0;i<cursor.getCount();i++){
	    	
	    	item=new HashMap<String,Object>();   
        //存放id日期和标题	
	    	item.put("id", cursor.getString(cursor.getColumnIndex("id")));
	    	item.put("date", cursor.getString(cursor.getColumnIndex("date")));
	    	item.put("title", cursor.getString(cursor.getColumnIndex("title")));
	    	data.add(item);
	    	cursor.moveToNext();
	    
	    }
	    
	    noteList=(ListView)findViewById(R.id.notelist);
	    //创建适配器
	    SimpleAdapter adapter=new SimpleAdapter
	    		(NotpadActivity.this,data,R.layout.message,new String[]{"id","title","date"},
	    				new int[]{R.id.id,R.id.title_list,R.id.date_list});
	    noteList.setAdapter(adapter);
	    
	    //item点击事件
	    noteList.setOnItemClickListener(new OnItemClickListener() {

	    	
	    	/**
	    	 * 点击响应事件
	    	 */
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, final int position,
					final long id) {
				@SuppressWarnings("unchecked")
				HashMap<String,Object> item=(HashMap<String, Object>) noteList.getItemAtPosition(position);
				   final Object noteID= item.get("id");
					
					//添加是否确认删除警告框
					Dialog  dialog = new AlertDialog.Builder(NotpadActivity.this)
					.setTitle("删除信息").setMessage("您确定要删除吗？")
					.setPositiveButton("确定", new DialogInterface.OnClickListener() {					
						/**
						 *确定点击事件响应
						 */
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
					   
							NotePadData dbHelper=new NotePadData(NotpadActivity.this);
							//根据id删除
							SQLiteDatabase db=dbHelper.getWritableDatabase();
							db.execSQL("delete from notepad where id=? ", new Object[]{noteID});
							db.close();
						
							onCreate(null);

						}
					}).setNegativeButton("取消", new DialogInterface.OnClickListener() {
						
						
						/**
						 *取消点击事件响应
						 */
						public void onClick(DialogInterface dialog, int which) {
							
		                     dialog.cancel();//关闭窗口
							
						}
					}).create();
					
					dialog.show();//显示窗口

			}
		});
	    
	    
	    //item长按事件
	    noteList.setOnItemLongClickListener(new OnItemLongClickListener() {
       
	    /**
	     * item长按事件响应
	     */
			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int position, long id) {
		
				
				@SuppressWarnings("unchecked")
				HashMap<String,Object> item=(HashMap<String, Object>) noteList.getItemAtPosition(position);
				   Object noteID= item.get("id");
				   Object date=item.get("date");
				   Object title=item.get("title");
				   String contentDetail = null;
				   String update_tag="1";
				   cursor.moveToFirst();
				   //通过遍历找到相同id取值
				   for(int i=0;i<cursor.getCount();i++){
					   
					   if(noteID.equals(cursor.getString(cursor.getColumnIndex("id")))){
						   contentDetail=cursor.getString(cursor.getColumnIndex("contentDetail"));
						   cursor.moveToLast();			
					   }
					   else{
						   cursor.moveToPosition(i+1);
					   }
				   }
				   //传递值
				   Intent intent=new Intent(NotpadActivity.this,WriteActivity.class);				  
				   Bundle bundle=new Bundle();
				   bundle.putString("id", (String) noteID);
				   bundle.putString("date", (String)date);
				   bundle.putString("title", (String)title);
				   bundle.putString("contentDetail", contentDetail);
				   bundle.putString("update_tag", update_tag);
				   intent.putExtras(bundle);
				   startActivity(intent);
				   NotpadActivity.this.finish();
				return false;
			}
		});
       
       
       //新建按钮点击事件
       startBtn.setOnClickListener(new OnClickListener() {
		/**
		 * 新建按钮点击事件响应方法
		 */

		public void onClick(View v) {
			Intent intent= new Intent(NotpadActivity.this,
					WriteActivity.class);
			startActivity(intent);// 跳转
			
		}
	});

    }
    /**
	 * 按键按下的响应事件
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// 在当前页面退出
			ExitManager.getInstance().exit(this);
		}
		return false;
	}

}